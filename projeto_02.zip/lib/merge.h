#ifndef MERGE_H
#define MERGE_H
#include "util.h"
Data mergeSort(int *array, int size);
#endif
