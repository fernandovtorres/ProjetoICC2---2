#ifndef COUNTING_H
#define COUNTING_H
#include "util.h"
Data countingSort(int *array, int size);
#endif
