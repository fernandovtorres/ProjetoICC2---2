#ifndef SELECTION_H
#define SELECTION_H
#include "util.h"
Data selectionSort(int *array, int size);
#endif
