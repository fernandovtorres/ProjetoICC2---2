#ifndef INSERTION_H
#define INSERTION_H
#include "util.h"
Data insertionSort(int *array, int size);
#endif
