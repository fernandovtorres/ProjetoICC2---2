#ifndef QUICK_H
#define QUICK_H
#include "util.h"
Data quickSort(int *array, int size);
#endif
