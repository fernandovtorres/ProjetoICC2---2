#ifndef BUBBLE_H
#define BUBBLE_H
#include "util.h"
Data bubbleSort(int *array, int size);
#endif
